import AppKit
import Cocoa
import SpriteKit


public class GameViewController: NSViewController{
    
    lazy var skView: SKView = {
        let gameView = SKView(frame: NSRect(x: -100, y: 0, width: 4000, height: 4000))
        gameView.autoresizingMask = [.width, .height]
        
        print("game view frame")
        
        return gameView
    }()
    
    var scene: GameScene?
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        print("View did load game view controller")
    }
    
    override public func loadView() {
        view = NSView(frame: NSRect(x: -100, y: 0, width: 4000, height: 4000))
        
        view.addSubview(skView)
        print("Load view game view controller")
        print(view.frame)
    }
    
    override public func viewDidLayout() {
        super.viewDidLayout()
        
        skView.frame = view.bounds
        
        print("view did layout game view controller")
    }
    
    override public func viewDidAppear() {
        print("view did appear game view controller")
        if skView.scene == nil {
            print("skview scene is nil")
            scene = GameScene(size: skView.frame.size)
            skView.presentScene(scene)
        }
    }
}


